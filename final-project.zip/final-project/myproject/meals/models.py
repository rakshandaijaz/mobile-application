from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Products(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    size=models.TextField(max_length=50,default='Default Size')
    def __str__(self):
        return self.name
class Order(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Canceled', 'Canceled'),
        ('Completed', 'Completed'),
    ]
    quantity = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.quantity

class Orders(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)
    total=models.DecimalField(max_digits=10,decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    adress=models.TextField(default='adress')

    def __str__(self):
        return f"orders {self.id} by {self.user.username}"
class Review(models.Model):
    user = models.ForeignKey(
        User, on_delete=models.CASCADE,null=True, blank=True
    )
    product = models.ForeignKey(Products, on_delete=models.CASCADE,related_name='reviews')
    rating = models.FloatField()  # Changed from PositiveIntegerField to FloatField for rating
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return f"Review for {self.product.name} by {self.user.username if self.user else 'Anonymous'}"   
# class CartItem(models.Model):
#     product = models.ForeignKey(Products, on_delete=models.CASCADE)
#     quantity = models.PositiveIntegerField(default=1)
#     user = models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)

#     def __str__(self):
#         return f"{self.product.name} - {self.quantity}"

# class Checkout(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)
#     address = models.CharField(max_length=500)
#     city = models.CharField(max_length=100)
#     country = models.CharField(max_length=100)
#     total_price = models.DecimalField(max_digits=10, decimal_places=2)

#     def __str__(self):
#         return f"Checkout for {self.user.username} - Total: ${self.total_price}"
class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Cart of {self.user if self.user else 'Guest'}"

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, related_name="items", on_delete=models.CASCADE)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    orders=models.ForeignKey(Orders,on_delete=models.CASCADE,null=True,blank=True)
    def __str__(self):
        return f"{self.quantity} x {self.product.name} in cart"
      
# class Cart(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)
#     date_created = models.DateTimeField(auto_now_add=True)

#     def __str__(self):
#         return f"Cart for {self.user.username}"
# class CartItem(models.Model):
#     product = models.ForeignKey(Products, on_delete=models.CASCADE)
#     quantity = models.PositiveIntegerField(default=0)
#     user = models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)
#     date_added = models.DateTimeField(default=timezone.now)

#     def __str__(self):
#         return f'{self.quantity} x {self.product.name}'

# class Cart(models.Model):
#     created_at = models.DateTimeField(auto_now_add=True)

#     def __str__(self):
#         return f"Cart {self.id}"

#     @property
#     def total_price(self):
#         return sum(item.total_price for item in self.items.all())


# class CartItem(models.Model):
#     cart = models.ForeignKey(Cart, related_name='items', on_delete=models.CASCADE)
#     product = models.ForeignKey(Products, on_delete=models.CASCADE)
#     quantity = models.PositiveIntegerField(default=1)

#     def __str__(self):
#         return f"{self.product.name} - {self.quantity}"

#     @property
#     def total_price(self):
#         return self.product.price * self.quantity

