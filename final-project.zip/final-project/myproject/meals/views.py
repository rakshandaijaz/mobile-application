from .serializers import UserSerializer
from rest_framework.parsers import JSONParser
from django.views import View
from django.shortcuts import  get_object_or_404
import json
from rest_framework import generics
from .models import Products,CartItem
from .serializers import ProductsSerializer  # Rename this import to match the renamed serializer class
from .models import Order,Orders
from .serializers import OrderSerializer,OrdersSerializer,CartItemSerializer
from rest_framework.permissions import IsAuthenticated
from .models import  Review
from .serializers import ReviewSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from .models import Products
from rest_framework_simplejwt.views import TokenObtainPairView
from .serializers import CustomTokenObtainPairSerializer
from django.contrib.auth.models import User
from django.http import JsonResponse
from .serializers import UserSerializer
class ProductsCreateView(generics.CreateAPIView):
    queryset = Products.objects.all() 
    serializer_class = ProductsSerializer  
class ProductsListView(generics.ListAPIView):
    queryset = Products.objects.all() 
    serializer_class = ProductsSerializer 
class OrdersCreateView(generics.CreateAPIView):
    # queryset = Products.objects.all() 
    serializer_class = OrdersSerializer
    permission_classes=[IsAuthenticated] 
class OrdersListView(generics.ListAPIView):
    serializer_class = OrdersSerializer # Require authentication
    queryset = Order.objects.all()
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
class ProductReviewsView(APIView):
    def get(self, request, product_id):
        # Fetch reviews for the specific product ID
        reviews = Review.objects.filter(product_id=product_id)  # Correct filter for product_id
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data)

    def post(self, request, product_id):
        # Ensure the user is authenticated, otherwise don't set a user
        user = request.user if request.user.is_authenticated else None
        
        # Add the product_id to the request data, mapping it to the URL param
        data = request.data.copy()
        data['product'] = product_id
        
        # Serialize the data
        serializer = ReviewSerializer(data=data)
        
        # Validate and save the review
        if serializer.is_valid():
            review = serializer.save(user=user)  # Save the review with user if available
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
# class CartView(generics.RetrieveAPIView):
#         serializer_class=CartItemSerializer
#         permission_classes=[IsAuthenticated]
#         def get_object(self):
#             cart,_=Cart.objects.get_or_create(user=self.request.user)
#             return cart
# class AddToCartView(generics.CreateAPIView):
#     permission_classes = [IsAuthenticated]  # Optional: make sure the user is logged in
#     serializer_class=AddToCartSerializer
#     def perform(self,serilizer):
#         cart,_=Cart.objects.get_or_create(user=self.request.user)
#         product_id=self.request.data.get('product_id')
#         if not product_id:
#             raise serilizer.ValidationError('product_id is required')
        
#         try:
#             product=Products.objects.get
#         except Products.DoesNotExist:
#             raise serilizer.ValidationError('invalid Product_id')
#         serilizer.save(cart=cart,product=product)
       
class AddToCartView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        product_id = request.data.get('product_id')
        quantity = request.data.get('quantity', 1)

        try:
            product = Products.objects.get(id=product_id)
            cart_item, created = CartItem.objects.get_or_create(
                product=product,
                user=request.user,
                defaults={'quantity': quantity}
            )
            if not created:
                cart_item.quantity += quantity
                cart_item.save()

            serializer = CartItemSerializer(cart_item)
            return Response({"message": "Product added to cart", "cart_item": serializer.data})
        except Products.DoesNotExist:
            return Response({"message": "Product not found"}, status=404)

from .serializers import CheckoutSerializer

class CheckoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = CheckoutSerializer(data=request.data)
        if serializer.is_valid():
            cart_items = CartItem.objects.filter(user=request.user)
            if not cart_items:
                return Response({"message": "Your cart is empty."}, status=400)

            # Calculate total price
            total_price = sum(item.product.price * item.quantity for item in cart_items)
            serializer.save(user=request.user, total_price=total_price)

            # Empty the cart after successful checkout
            cart_items.delete()

            return Response({"message": "Checkout successful", "checkout_data": serializer.data})
        return Response(serializer.errors, status=400)
# class ProductReviewsView(APIView):
#     def get(self, request, product_id):
#         # Fetch reviews for the specific product ID using the correct column (product_id)
#         reviews = Review.objects.filter(product_id=product_id)  # This is correct
#         serializer = ReviewSerializer(reviews, many=True)
#         return Response(serializer.data)

#     def post(self, request, product_id):
#         # Ensure the user is authenticated, otherwise don't set a user
#         user = request.user if request.user.is_authenticated else None
        
#         # Add the product_id to the request data, mapping it to the URL param
#         data = request.data.copy()
#         data['product'] = product_id  # We add the product_id to the request data to associate the review
        
#         # Serialize the data
#         serializer = ReviewSerializer(data=data)
        
#         # Validate and save the review
#         if serializer.is_valid():
#             review = serializer.save(user=user)  # Save the review with the user (if authenticated)
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
        
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
# class ProductReviewsView(APIView):
#     def get(self, request, product_id):
#         # Fetch reviews for the specific product ID using the correct column (product_id)
#         reviews = Review.objects.filter(product_id=product_id)  # This is correct
#         serializer = ReviewSerializer(reviews, many=True)
#         return Response(serializer.data)

#     def post(self, request, product_id):
#         # No authentication check, just create a review
#         data = request.data.copy()
#         data['product'] = product_id  # Add the product_id to the request data
        
#         # Serialize the data
#         serializer = ReviewSerializer(data=data)
        
#         # Validate and save the review
#         if serializer.is_valid():
#             review = serializer.save()  # Save the review without associating it with a user
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
        
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class UserOrderListView(generics.ListAPIView):
    serializer_class = OrderSerializer # Require authentication
    queryset = Order.objects.all() 
class CreateOrderView(generics.CreateAPIView):
    serializer_class=OrderSerializer
    permission_classes=[IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
class ReviewsListView(generics.ListAPIView):
    queryset = Review.objects.all() 
    serializer_class = ReviewSerializer


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class=CustomTokenObtainPairSerializer
def get_users(request):
    users = User.objects.all()  # Fetch all users from the database
    serializer = UserSerializer(users, many=True)  # Serialize the user data
    return JsonResponse(serializer.data, safe=False)
class UserEditView(View):
    def patch(self, request, username):
        user = get_object_or_404(User, username=username)
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        
        # Update fields if they exist in the request
        if 'email' in data:
            user.email = data['email']
        if 'username' in data:
            user.username = data['username']
        user.save()
        
        return JsonResponse({'message': 'User updated successfully'})

# Delete a user based on username
class UserDeleteView(View):
    def delete(self, request, username):
        user = get_object_or_404(User, username=username)
        user.delete()
        return JsonResponse({'message': 'User deleted successfully'}, status=204)