from django.urls import path
from .views import ProductsListView,ProductsCreateView
from .views import (
     
    UserOrderListView,
    ProductReviewsView,
    ReviewsListView,AddToCartView,
    OrdersCreateView,OrdersListView,
    CartView
)
from .views import CustomTokenObtainPairView
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
   
)
from . import views
urlpatterns = [
    path('meals/create/', ProductsCreateView.as_view(), name='products-create'),
    path('meals/', ProductsListView.as_view(), name='products-list'),
    path('orders/', UserOrderListView.as_view(), name='user-orders'), 
    path('orderss/create/', OrdersCreateView.as_view(), name='user-orderss'), 
    path('orderss/list/', OrdersListView.as_view(), name='user-orderss'), 
    #  path('add-to-cart/', AddToCartView.as_view(), name='add-to-cart'),
    # path('checkout/', CheckoutView.as_view(), name='checkout'),
      path('cart/', CartView.as_view(), name='cart-view'),
    path('cart/add/', AddToCartView.as_view(), name='add-to-cart'),
    path('products/<int:product_id>/review/', ProductReviewsView.as_view(), name='product-review-create'),
    path('add-to-cart/<int:product_id>/', AddToCartView.as_view(), name='add-to-cart'),
    path('review/list', ReviewsListView.as_view(), name='product-review-create'),
    # path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('users/', views.get_users, name='get_users'), 
    path('users/<str:username>/edit/', views.UserEditView.as_view(), name='user-edit'),
    path('users/<str:username>/delete/', views.UserDeleteView.as_view(), name='user-delete'),
    
    
]
