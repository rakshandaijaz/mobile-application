
from rest_framework import serializers
from .models import Products
from .models import Order,Orders
from .models import  Review,CartItem,Checkout
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework import serializers
from .models import User
from django.contrib.auth.models import User
class ProductsSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Products
        fields = '__all__'  #
class OrdersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Orders
        fields ='__all__'
        extra_kwargs={'user':{'read_only':True}}
class CartItemSerializer(serializers.ModelSerializer):
    product = ProductsSerializer()  # Nested serializer for the related product

    class Meta:
        model = CartItem
        fields = ['id', 'product', 'quantity']

class CheckoutSerializer(serializers.ModelSerializer):
    class Meta:
        model = Checkout
        fields = ['id', 'address', 'city', 'country', 'total_price']
# class CartItemSerializer(serializers.ModelSerializer):
#       product_name=serializers.CharField(source='product.name',read_only=True)
#       product_id=serializers.IntegerField(write_only=True)
#       price=serializers.DecimalField(source='product.price',max_digits=12,decimal_places=2,read_only=True)

#       class Meta:
#           model=CartItem
#           fields = ['id', 'product_id', 'product_name', 'price', 'quantity']
# class AddToCartSerializer(serializers.ModelSerializer):
#     items=CartItemSerializer(many=True,read_only=True)
#     class Meta:
#         model=Cart
#         fields=['id','user','items']
#         extra_kwargs={'user':{'read_only':True}}
class ReviewSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    product_name = serializers.CharField(source='product.name', read_only=True)
    product = serializers.PrimaryKeyRelatedField(queryset=Products.objects.all())

    class Meta:
        model = Review
        fields = ['id', 'username', 'product_name', 'product', 'rating', 'comment', 'created_at']
        read_only_fields = ['id', 'username', 'product_name', 'created_at']

    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value

    def validate_comment(self, value):
        if not value.strip():
            raise serializers.ValidationError("Comment cannot be empty.")
        return value
       
# class CartItemSerializer(serializers.ModelSerializer):
#     product = ProductsSerializer(read_only=True)  # Nest product details

#     class Meta:
#         model = CartItem
#         fields = ['id', 'product', 'quantity', 'date_added']

# class AddToCartSerializer(serializers.Serializer):
#     product_id = serializers.IntegerField()
#     quantity = serializers.IntegerField(default=1)
# class CartItemSerializer(serializers.ModelSerializer):
#     product = ProductsSerializer()

#     class Meta:
#         model = CartItem
#         fields = ['id', 'product', 'quantity', 'total_price']


# class CartSerializer(serializers.ModelSerializer):
#     items = CartItemSerializer(many=True)

#     class Meta:
#         model = Cart
#         fields = ['id', 'items', 'total_price']
# class AddToCartSerializer(serializers.Serializer):
#     product_id = serializers.IntegerField()
#     quantity = serializers.IntegerField(default=1)
class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields ='__all__'
        
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    # Custom field for user ID (if it's a custom field on the User model)
    userId = serializers.CharField(source='user.id', read_only=True)

    def validate(self, attrs):
        # Perform the default validation
        data = super().validate(attrs)
        
        # Add the userId (which is just the `id` field of the User model)
        data['userId'] = self.user.id  # Access the User's `id` directly

        return data


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']
