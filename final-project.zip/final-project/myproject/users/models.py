
# from django.contrib.auth.models import User
# from django.db import models
# class User(models.Model):
#     username=models.CharField(max_length=100)
#     password=models.CharField(max_length=100)


#     def __str__(self):
#         return self.username
    
# Remove this custom User model:
# from django.contrib.auth.models import User
# from django.db import models

# class User(models.Model):
#     username=models.CharField(max_length=100)
#     password=models.CharField(max_length=100)

#     def __str__(self):
#         return self.username

