
from django.contrib.auth.models import User
from rest_framework import serializers


class SignUpSerializer(serializers.ModelSerializer):  # Correct inheritance
    class Meta:
        model = User
        fields = ('username', 'password')
        extra_kwargs = {'password': {'write_only': True}}  # Fixed typo

    def create(self, validated_data):
        # Use create_user to ensure password is hashed
        user = User.objects.create_user(**validated_data)
        return user
    
    # serializers.py
# from django.contrib.auth.models import User
# from rest_framework import serializers

# class SignUpSerializer(serializers.ModelSerializer):
#     password = serializers.CharField(write_only=True)

#     class Meta:
#         model = User
#         fields = ('username', 'password', 'email')  # Add other fields as needed

#     def create(self, validated_data):
#         # Use create_user to ensure the password is hashed
#         user = User.objects.create_user(
#             username=validated_data['username'],
#             password=validated_data['password'],
#             email=validated_data.get('email', '')  # Optional field
#         )
#         return user
