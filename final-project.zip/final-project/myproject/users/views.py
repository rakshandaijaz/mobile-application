from django.shortcuts import render
from .serializers import SignUpSerializer
from django.contrib.auth.models import User
from rest_framework import generics

class SignUpView(generics.CreateAPIView):
    queryset=User.objects.all()
    serializer_class=SignUpSerializer

# Create your views here.
# views.py
# from django.shortcuts import render
# from .serializers import SignUpSerializer
# from django.contrib.auth.models import User
# from rest_framework import generics

# class SignUpView(generics.CreateAPIView):
#     queryset = User.objects.all()
#     serializer_class = SignUpSerializer
